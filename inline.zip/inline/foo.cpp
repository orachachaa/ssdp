#include <iostream>
#include "add.h"

void foo()
{
	add2(2, 3);

}