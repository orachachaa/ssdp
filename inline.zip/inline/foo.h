// foo.h
void foo();