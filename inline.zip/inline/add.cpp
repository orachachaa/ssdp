#include <iostream>

int add1(int a, int b)
{
	std::cout << "add1\n";
	return a + b;
}

int add2(int a, int b)
{
	std::cout << "add2\n";
	return a + b;
}