// add.h
#include <iostream>

int add1(int a, int b);
int add2(int a, int b);

