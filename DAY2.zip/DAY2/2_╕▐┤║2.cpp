﻿#include <iostream>
#include <string>
#include <vector>
#include <conio.h> 

int main()
{

}




