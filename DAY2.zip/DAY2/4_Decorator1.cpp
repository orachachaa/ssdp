﻿// Decorator - 65 page
#include <iostream>

class Image
{
public:
	void draw()	{ std::cout << "draw image\n"; }
};

int main()
{
	SpaceShip ss;
	ss.Fire();
}
